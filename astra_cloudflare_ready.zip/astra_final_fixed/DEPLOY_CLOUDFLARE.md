# Deploying Astra with GitHub + Cloudflare Pages

Cloudflare Pages/Workers cannot run a Flask + PostgreSQL app, so Astra is split in two:

    players -> Cloudflare Pages (functions/[[path]].js) -> Flask backend (Render) -> PostgreSQL (Neon)

Everyone uses ONE backend and ONE database, so friend requests, DMs and trades finally work.

## 1. Database (free): neon.tech
Create a project, copy the connection string (postgresql://...). This is your DATABASE_URL.

## 2. Backend: render.com
1. Push this folder to a GitHub repo.
2. Render -> New -> Blueprint -> pick the repo (it reads render.yaml).
3. When asked, paste DATABASE_URL. SECRET_KEY is generated for you. Keep it stable forever.
4. After deploy, note the URL, e.g. https://astra-backend.onrender.com
   Check https://astra-backend.onrender.com/api/ping loads.
   Optional env: ADMIN_USERNAMES, OPENAI_API_KEY.

## 3. Front door: Cloudflare Pages
1. Workers & Pages -> Create -> Pages -> Connect to Git -> pick the repo.
2. Framework preset: None. Build command: (leave empty). Build output directory: public
3. Settings -> Variables and Secrets -> add  BACKEND_URL = https://astra-backend.onrender.com
4. Redeploy. Your game is now at https://<project>.pages.dev

## 4. The exe
Beside astra.exe put a .env containing only:
    ASTRA_SERVER_URL=https://<project>.pages.dev
Everyone (exe and browser) now shares one world. Register accounts again on it.

## Notes
- Render's free plan sleeps after ~15 min idle; the first request then takes ~30-60 s.
- Pages Functions free plan = 100,000 requests/day. The game polls about every 1.5 s
  (~2,400 requests per player-hour), so that is roughly 40 player-hours per day.
- If you use the anti-tamper lock, run `python sign_release.py sign` after these edits
  (new files were added) and commit astra_manifest.json / astra_manifest.sig.
- Never commit .env or your private signing key (.gitignore already excludes them).
