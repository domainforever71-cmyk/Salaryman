// ======================= EDIT ME =======================
let wallet = 2500;                       // starting money (hook this to your game balance)
const TAXI_FARE_PER_KM = 2;
const HOMES = [                          // the 3 apartments. sale = % discount
  { id: "apartmentsA", name: "Neon Heights",    tag: "Budget studio",    rooms: 1, size: 38,  floor: "2nd", price: 1800, sale: 20, keywords: "cheap budget small studio sale" },
  { id: "apartmentsB", name: "Greenline Flats", tag: "Family flat",      rooms: 2, size: 64,  floor: "5th", price: 2400, sale: 0,  keywords: "family standard" },
  { id: "apartmentsC", name: "Harbor Court",    tag: "Luxury penthouse", rooms: 3, size: 110, floor: "Top", price: 4200, sale: 10, keywords: "luxury expensive big penthouse sale" },
];
const SUPERMARKET_ITEMS = [["Bread", 3], ["Milk", 2], ["Instant noodles", 1], ["Coffee", 5], ["Energy drink", 4]];
const CARS = [["Rusty Hatchback", 1800], ["City Sedan", 6500], ["Night Coupe", 14000]];
// Where each place sits: [column 0-9, row 1-4]. The map is 10 x 6 blocks (3000 x 1800).
const BLOCK = { supermarket: [3, 2], carshop: [6, 3], apartmentsA: [1, 1], apartmentsB: [7, 4], apartmentsC: [3, 4] };
window.onApartmentPaid = (info) => console.log("PAID", info);   // connect to your backend here
// =======================================================

const W = 3000, H = 1800, P = 300, BS = 264, MAXS = 2.4;
const $ = (id) => document.getElementById(id);
const overlay = $("overlay"), winTitle = $("winTitle"), winBody = $("winBody"), status = $("status"), svg = $("map");
const money = (n) => "$" + Math.round(n).toLocaleString();
const finalPrice = (h) => Math.round(h.price * (1 - h.sale / 100));
const OWNED = {};
const NAMES = { supermarket: "Supermarket", carshop: "Car Shop", ...Object.fromEntries(HOMES.map((h) => [h.id, h.name])) };
const origin = (id) => [BLOCK[id][0] * P + 18, BLOCK[id][1] * P + 18];
const centerOf = (id) => { const [x, y] = origin(id); return [x + BS / 2, y + BS / 2]; };
const DOORS = Object.fromEntries(Object.keys(BLOCK).map((k) => [k, [BLOCK[k][0] * P + 150, BLOCK[k][1] * P]]));   // on the road above each block

function openWindow(title, html) { winTitle.textContent = title; winBody.innerHTML = html; overlay.hidden = false; $("winClose").focus(); }
function closeWindow() { overlay.hidden = true; }
$("winClose").onclick = closeWindow;
overlay.addEventListener("click", (e) => { if (e.target === overlay) closeWindow(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeWindow(); });
const setWallet = () => ($("wallet").textContent = money(wallet));
setWallet();

// ---------- rooftop art (top-down, hard shadows) ----------
const TERRA = ["#ee9a6c", "#d4794f", "#b5603e"], GREY = ["#9298a3", "#777d88", "#5d636d"], BROWN = ["#b07a52", "#93613f", "#76492f"], SLATE = ["#7d8aa0", "#66738a", "#4f5b70"];
const sh = (x, y, w, h) => `<rect class="sh" x="${x + 7}" y="${y + 9}" width="${w}" height="${h}" rx="2"/>`;
const poly = (p, c) => `<polygon points="${p.map((q) => q.join(",")).join(" ")}" fill="${c}"/>`;
function hip(x, y, w, h, c) {
  const m = Math.min(w, h) / 2, T = [x, y], R = [x + w, y], B = [x + w, y + h], L = [x, y + h]; let a, b, f;
  if (w >= h) { a = [x + m, y + h / 2]; b = [x + w - m, y + h / 2]; f = poly([T, R, b, a], c[0]) + poly([L, B, b, a], c[2]) + poly([T, L, a], c[1]) + poly([R, B, b], c[2]); }
  else { a = [x + w / 2, y + m]; b = [x + w / 2, y + h - m]; f = poly([T, L, b, a], c[0]) + poly([R, B, b, a], c[2]) + poly([T, R, a], c[1]) + poly([L, B, b], c[2]); }
  return sh(x, y, w, h) + f + `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="none" stroke="rgba(0,0,0,.4)"/><line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="rgba(0,0,0,.35)"/>`;
}
const flat = (x, y, w, h, c) => sh(x, y, w, h) + `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${c}" stroke="rgba(0,0,0,.45)" stroke-width="2"/><rect x="${x + 4}" y="${y + 4}" width="${w - 8}" height="${h - 8}" fill="none" stroke="rgba(0,0,0,.18)"/>`;
const ac = (x, y) => `<rect x="${x + 3}" y="${y + 4}" width="14" height="14" fill="rgba(0,0,0,.4)"/><rect x="${x}" y="${y}" width="14" height="14" fill="#cfd3d6" stroke="rgba(0,0,0,.4)"/><circle cx="${x + 7}" cy="${y + 7}" r="4" fill="#8b949c"/>`;
const dormer = (x, y) => `<rect x="${x + 2}" y="${y + 3}" width="13" height="11" fill="rgba(0,0,0,.4)"/><rect x="${x}" y="${y}" width="13" height="11" fill="#efe3cf" stroke="rgba(0,0,0,.45)"/><line x1="${x + 6.5}" y1="${y}" x2="${x + 6.5}" y2="${y + 11}" stroke="rgba(0,0,0,.35)"/>`;
const car = (x, y, col, v) => v
  ? `<rect x="${x + 2}" y="${y + 2}" width="10" height="18" rx="3" fill="rgba(0,0,0,.45)"/><rect x="${x}" y="${y}" width="10" height="18" rx="3" fill="${col}"/><rect x="${x + 2}" y="${y + 5}" width="6" height="8" fill="rgba(0,0,0,.55)"/>`
  : `<rect x="${x + 2}" y="${y + 2}" width="18" height="10" rx="3" fill="rgba(0,0,0,.45)"/><rect x="${x}" y="${y}" width="18" height="10" rx="3" fill="${col}"/><rect x="${x + 5}" y="${y + 2}" width="8" height="6" fill="rgba(0,0,0,.55)"/>`;
const tree = (x, y, r) => `<circle cx="${x + 5}" cy="${y + 6}" r="${r}" fill="rgba(0,0,0,.4)"/><circle cx="${x}" cy="${y}" r="${r}" fill="#5aa83a"/><circle cx="${x - r / 3}" cy="${y - r / 3}" r="${r / 2}" fill="#86cf5c"/>`;
const CC = ["#e0b341", "#3d78c9", "#d9d9d9", "#c2423f", "#8a5bd6", "#00ffcc", "#ff3366"];
const lot = (x, y, w, h) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#14171b" stroke="#000"/>`;

// all art is drawn inside a 264 x 264 block, (0,0) = block corner
const ART = {
  apartmentsA: () => hip(20, 26, 224, 104, TERRA) + hip(20, 120, 104, 110, BROWN) + dormer(44, 34) + dormer(112, 34) + dormer(180, 34) + dormer(36, 140) + tree(190, 196, 14) + tree(222, 222, 11) + car(150, 214, "#3d78c9"),
  apartmentsB: () => flat(16, 24, 232, 170, "#ddd7c5") + flat(28, 36, 44, 34, "#bcb5a2") + ac(100, 40) + ac(134, 40) + ac(190, 40) + ac(210, 150)
    + `<rect x="30" y="100" width="90" height="80" fill="#2f5f9a" stroke="#000" stroke-opacity=".5"/><path d="M30 120H120M30 140H120M30 160H120M60 100V180M90 100V180" stroke="#9fc2ea" stroke-opacity=".6"/>`
    + `<rect x="140" y="96" width="76" height="46" rx="8" fill="#38b6d8" stroke="#fff" stroke-opacity=".7" stroke-width="3"/><path d="M150 112H206M150 126H206" stroke="#fff" stroke-opacity=".3"/>`
    + lot(16, 204, 232, 46) + car(30, 216, "#e0b341") + car(90, 216, "#d9d9d9") + car(150, 216, "#c2423f") + car(206, 216, "#3d78c9"),
  apartmentsC: () => hip(14, 18, 236, 150, SLATE) + dormer(38, 30) + dormer(90, 30) + dormer(142, 30) + dormer(194, 30) + dormer(66, 130) + dormer(166, 130)
    + `<rect x="120" y="76" width="16" height="16" fill="#5a4a44" stroke="#000" stroke-opacity=".5"/>` + lot(14, 180, 160, 66) + car(26, 196, "#00ffcc") + car(80, 196, "#ff3366") + car(134, 196, "#d9d9d9") + tree(210, 214, 16) + tree(238, 190, 11),
  supermarket: () => {
    let s = flat(14, 14, 236, 118, "#e6e3d8") + `<rect x="14" y="126" width="236" height="6" fill="#ff3366"/>`;
    for (let i = 0; i < 5; i++) s += `<rect x="${30 + i * 36}" y="28" width="24" height="50" fill="#6fb3a0" stroke="#000" stroke-opacity=".35"/>`;
    s += ac(40, 94) + ac(70, 94) + ac(200, 94) + ac(200, 28) + lot(14, 142, 236, 104);
    for (let i = 0; i <= 10; i++) s += `<line x1="${18 + i * 22}" y1="148" x2="${18 + i * 22}" y2="188" stroke="#fff" stroke-opacity=".35"/><line x1="${18 + i * 22}" y1="200" x2="${18 + i * 22}" y2="240" stroke="#fff" stroke-opacity=".35"/>`;
    for (let i = 0; i < 10; i += 2) s += car(24 + i * 22, 152, CC[i % 7]) + (i % 4 ? car(24 + i * 22, 212, CC[(i + 3) % 7]) : "");
    return s;
  },
  carshop: () => {
    let s = flat(14, 14, 150, 108, "#8d939c") + `<rect x="14" y="14" width="150" height="14" fill="#ff3366"/>` + ac(30, 40) + ac(60, 40) + `<rect x="100" y="40" width="48" height="50" fill="#5d636d" stroke="#000" stroke-opacity=".4"/>`;
    for (let i = 0; i < 3; i++) s += `<rect x="${24 + i * 46}" y="116" width="34" height="6" fill="#0c0f13"/>`;
    s += lot(172, 14, 78, 232) + lot(14, 132, 150, 114);
    for (let i = 0; i < 5; i++) s += car(180, 22 + i * 44, CC[i], 1) + (i % 2 ? "" : car(212, 22 + i * 44, CC[i + 2], 1));
    for (let i = 0; i < 3; i++) s += car(24 + i * 46, 142, CC[i + 1]) + car(24 + i * 46, 196, CC[i + 3]);
    return s;
  },
};
const LABEL = { apartmentsA: [132, 84], apartmentsB: [132, 100], apartmentsC: [132, 100], supermarket: [132, 84], carshop: [89, 74] };
function tagText(h) { return OWNED[h.id] ? "OWNED" : h.sale ? `${money(finalPrice(h))}  -${h.sale}%` : money(finalPrice(h)); }
function drawPlaces() {
  $("places").innerHTML = Object.keys(ART).map((id) => {
    const h = HOMES.find((x) => x.id === id), [ox, oy] = origin(id), [lx, ly] = LABEL[id];
    return `<g class="place" id="${id}" tabindex="0" role="button" aria-label="${NAMES[id]}" transform="translate(${ox} ${oy})"><g class="art">${ART[id]()}</g>
      <rect class="hit" x="4" y="4" width="256" height="256"/><text class="plabel" x="${lx}" y="${ly}">${NAMES[id].toUpperCase()}</text>
      ${h ? `<text class="ptag ${OWNED[id] ? "own" : ""}" x="${lx}" y="${ly + 22}">${tagText(h)}</text>` : ""}</g>`;
  }).join("");
  document.querySelectorAll(".place").forEach((g) => {
    g.addEventListener("click", () => openPlace(g.id));
    g.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openPlace(g.id); } });
  });
}

// ---------- build the big city ----------
(function build() {
  let seed = 11; const r = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  const used = Object.fromEntries(Object.values(BLOCK).map(([i, j]) => [i + "," + j, 1]));
  const pal = [TERRA, GREY, BROWN, SLATE];
  let ground = `<rect width="${W}" height="${H}" fill="#14171b"/>`, fill = "", mini = `<rect width="${W}" height="${H}" fill="#0c0f13"/>`;
  for (let j = 0; j < 6; j++) for (let i = 0; i < 10; i++) {
    const bx = i * P + 18, by = j * P + 18, key = i + "," + j, park = key === "4,4" || key === "5,4";
    const tint = park ? "#1b2a21" : i <= 2 ? "#232a30" : i <= 6 ? "#272a33" : "#2a2825";
    ground += `<rect x="${bx}" y="${by}" width="${BS}" height="${BS}" fill="${tint}"/>`;
    mini += `<rect x="${bx}" y="${by}" width="${BS}" height="${BS}" fill="${park ? "#1f4a30" : "#222a31"}"/>`;
    if (used[key]) continue;
    let o = "";
    if (key === "4,4") o += `<ellipse cx="${132 + 8}" cy="${138}" rx="108" ry="78" fill="#10394a"/><ellipse cx="132" cy="132" rx="104" ry="74" fill="#1d6a86" stroke="#38b6d8" stroke-width="3"/><ellipse cx="116" cy="118" rx="50" ry="26" fill="#2b86a6" opacity=".6"/>` + [...Array(8)].map(() => tree(r() * 250 + 6, r() * 250 + 6, 7 + r() * 5)).join("");
    else if (key === "5,4") for (let k = 0; k < 26; k++) o += tree(14 + r() * 236, 14 + r() * 236, 8 + r() * 7);
    else if (i >= 8) { // industrial warehouses
      o += flat(14, 14, 236, 96, "#9aa0a8") + ac(30, 28) + ac(60, 28) + ac(200, 28) + `<path d="M14 62H250M14 84H250" stroke="rgba(0,0,0,.25)"/>` + flat(14, 124, 110, 120, "#848a93") + lot(136, 124, 114, 120) + car(146, 136, "#e0b341", 1) + car(176, 136, "#d9d9d9", 1) + car(206, 136, "#c2423f", 1);
    } else {
      const cols = 2, rows = r() > .35 ? 2 : 1, cw0 = (BS - 20) / cols, ch0 = (BS - 20) / rows;
      for (let a = 0; a < cols; a++) for (let b = 0; b < rows; b++) {
        const w = cw0 - 12 - r() * 12, h = ch0 - 12 - r() * 28, x = 10 + a * cw0 + 4 + r() * 6, y = 10 + b * ch0 + 4 + r() * 8;
        o += r() > .35 ? hip(x, y, w, h, pal[Math.floor(r() * 4)]) : flat(x, y, w, h, "#d8d2c0") + ac(x + 8, y + 8);
        if (r() > .6) o += tree(x + w + 2, y + h - 6, 7);
      }
    }
    fill += `<g transform="translate(${bx} ${by})">${o}</g>`;
  }
  // roads, lane lines
  let roads = `<g class="roads">`, dash = `<g class="dash">`, lab = "";
  const hn = ["BROKER AVE", "MARKET ST", "WALL ST", "CHARTER RD", "HARBOR AVE"];
  for (let j = 1; j < 6; j++) { const y = j * P; roads += `<rect x="0" y="${y - 18}" width="${W}" height="36"/>`; dash += `<line x1="0" y1="${y}" x2="${W}" y2="${y}"/>`; for (let k = 0; k < 3; k++) lab += `<text class="st" x="${300 + k * 1000}" y="${y + 5}">${hn[j - 1]}</text>`; mini += `<rect x="0" y="${y - 10}" width="${W}" height="20" fill="#0a0d11"/>`; }
  for (let i = 1; i < 10; i++) { const x = i * P; roads += `<rect x="${x - 18}" y="0" width="36" height="${H}"/>`; dash += `<line x1="${x}" y1="0" x2="${x}" y2="${H}"/>`; for (let k = 0; k < 2; k++) lab += `<text class="st" transform="translate(${x + 5} ${300 + k * 900}) rotate(90)">${i}${["TH", "ST", "ND", "RD"][i > 3 ? 0 : i % 4] || "TH"} ST</text>`; mini += `<rect x="${x - 10}" y="0" width="20" height="${H}" fill="#0a0d11"/>`; }
  roads += "</g>"; dash += "</g>";
  [["RESIDENTIAL", 450, 1000], ["DOWNTOWN", 1350, 700], ["CITY PARK", 1650, 1560], ["INDUSTRIAL", 2550, 1000]].forEach(([t, x, y]) => (lab += `<text class="dist" x="${x}" y="${y}">${t}</text>`));
  $("ground").innerHTML = ground + roads + dash; $("fillers").innerHTML = fill; $("labels").innerHTML = lab;
  $("border").innerHTML = `<rect class="limit" x="0" y="0" width="${W}" height="${H}"/><rect class="limit2" x="12" y="12" width="${W - 24}" height="${H - 24}"/>` + [[1500, 34], [1500, H - 22]].map(([x, y]) => `<text class="limtxt" x="${x}" y="${y}">CITY LIMIT</text>`).join("");
  drawPlaces();
  const cols = { supermarket: "#00ff66", carshop: "#ff3366" };
  Object.keys(BLOCK).forEach((id) => { const [x, y] = origin(id); mini += `<rect x="${x}" y="${y}" width="${BS}" height="${BS}" fill="${cols[id] || "#00ffcc"}"/>`; });
  $("mini").innerHTML = mini + `<rect id="mv" fill="rgba(255,187,0,.12)" stroke="#ffbb00" stroke-width="14"/><circle id="mt" r="45" fill="#ffbb00" hidden/>`;
})();

// ---------- camera: drag, keys, wheel, minimap, hard city limits ----------
const cam = { x: 0, y: 0, s: 0.9 }; let cw = 1, ch = 1, minS = 0.4, dirty = true;
const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
function flash(side) {
  const e = document.querySelector(".edge." + side); e.classList.add("on"); clearTimeout(e._t); e._t = setTimeout(() => e.classList.remove("on"), 280);
  status.textContent = "CITY LIMIT - you can't go any further that way.";
}
function view(report) {
  const vw = cw / cam.s, vh = ch / cam.s, mx = Math.max(0, W - vw), my = Math.max(0, H - vh);
  if (report) { if (cam.x < -0.5) flash("left"); else if (cam.x > mx + 0.5) flash("right"); if (cam.y < -0.5) flash("top"); else if (cam.y > my + 0.5) flash("bottom"); }
  cam.x = clamp(cam.x, 0, mx); cam.y = clamp(cam.y, 0, my);
  svg.setAttribute("viewBox", `${cam.x} ${cam.y} ${vw} ${vh}`);
  const mv = $("mv"); mv.setAttribute("x", cam.x); mv.setAttribute("y", cam.y); mv.setAttribute("width", vw); mv.setAttribute("height", vh);
}
function resize() { const b = svg.getBoundingClientRect(); cw = b.width; ch = b.height; minS = Math.max(cw / W, ch / H); cam.s = clamp(cam.s, minS, MAXS); view(false); }
svg.setAttribute("preserveAspectRatio", "none");
new ResizeObserver(resize).observe(svg);
function zoomAt(px, py, ns) { ns = clamp(ns, minS, MAXS); const wx = cam.x + px / cam.s, wy = cam.y + py / cam.s; cam.s = ns; cam.x = wx - px / ns; cam.y = wy - py / ns; view(false); }
let anim = null, follow = false;
function flyTo(wx, wy, s, done) { anim = { t0: performance.now(), dur: 750, fx: cam.x + cw / 2 / cam.s, fy: cam.y + ch / 2 / cam.s, fs: cam.s, tx: wx, ty: wy, ts: clamp(s, minS, MAXS), done }; follow = false; }
$("zIn").onclick = () => zoomAt(cw / 2, ch / 2, cam.s * 1.3);
$("zOut").onclick = () => zoomAt(cw / 2, ch / 2, cam.s / 1.3);
$("zHome").onclick = () => flyTo(1050, 750, 0.9);

// drag to move
let drag = null, moved = false;
svg.addEventListener("pointerdown", (e) => { if (e.button) return; drag = { x: e.clientX, y: e.clientY, cx: cam.x, cy: cam.y }; moved = false; anim = null; follow = false; });
window.addEventListener("pointermove", (e) => {
  if (!drag) return;
  const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
  if (!moved && Math.hypot(dx, dy) > 5) { moved = true; svg.classList.add("grabbing"); }
  if (moved) { cam.x = drag.cx - dx / cam.s; cam.y = drag.cy - dy / cam.s; view(true); }
});
window.addEventListener("pointerup", () => { drag = null; svg.classList.remove("grabbing"); });
svg.addEventListener("click", (e) => { if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; } }, true);
svg.addEventListener("wheel", (e) => { e.preventDefault(); const b = svg.getBoundingClientRect(); zoomAt(e.clientX - b.left, e.clientY - b.top, cam.s * Math.exp(-e.deltaY * 0.0015)); }, { passive: false });
svg.addEventListener("mousemove", (e) => {
  if (e.target.closest(".place") || drag) return;
  const b = svg.getBoundingClientRect(); status.textContent = `Grid X:${Math.round(cam.x + (e.clientX - b.left) / cam.s)} Y:${Math.round(cam.y + (e.clientY - b.top) / cam.s)}`;
});
// minimap: click or drag to jump
let mdrag = false;
const jump = (e) => { const b = $("mini").getBoundingClientRect(); cam.x = ((e.clientX - b.left) / b.width) * W - cw / 2 / cam.s; cam.y = ((e.clientY - b.top) / b.height) * H - ch / 2 / cam.s; anim = null; follow = false; view(false); };
$("mini").addEventListener("pointerdown", (e) => { mdrag = true; jump(e); });
window.addEventListener("pointermove", (e) => { if (mdrag) jump(e); });
window.addEventListener("pointerup", () => (mdrag = false));
// keyboard
const keys = new Set(); let vx = 0, vy = 0;
const typing = () => /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName) || !overlay.hidden;
window.addEventListener("keydown", (e) => { if (!typing()) { const k = e.key.toLowerCase(); if ("wasd".includes(k) && k.length === 1 || k.startsWith("arrow") || "+=-_".includes(k)) { keys.add(k); e.preventDefault(); } if (k === "0" || k === "home") $("zHome").click(); } });
window.addEventListener("keyup", (e) => keys.delete(e.key.toLowerCase()));
window.addEventListener("blur", () => keys.clear());

// ---------- ambient traffic ----------
const traffic = [];
for (let n = 0; n < 34; n++) {
  const horiz = n % 2 === 0, road = 1 + Math.floor(Math.random() * (horiz ? 5 : 9)), dir = Math.random() < .5 ? 1 : -1;
  traffic.push({ horiz, road, dir, sp: 50 + Math.random() * 60, p: Math.random() * (horiz ? W : H), col: CC[n % 7] });
}
$("traffic").innerHTML = traffic.map((c) => `<g class="tc"><rect x="-8" y="-3" width="18" height="10" rx="3" fill="rgba(0,0,0,.4)"/><rect x="-9" y="-5" width="18" height="10" rx="3" fill="${c.col}"/><rect x="-3" y="-3" width="8" height="6" fill="rgba(0,0,0,.55)"/></g>`).join("");
const tEls = [...document.querySelectorAll(".tc")];

// ---------- main loop ----------
let last = performance.now(), taxiRun = null;
function tick(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (typing()) keys.clear();
  const ax = (keys.has("d") || keys.has("arrowright") ? 1 : 0) - (keys.has("a") || keys.has("arrowleft") ? 1 : 0), ay = (keys.has("s") || keys.has("arrowdown") ? 1 : 0) - (keys.has("w") || keys.has("arrowup") ? 1 : 0);
  const sp = 700 / cam.s; vx += (ax * sp - vx) * Math.min(1, dt * 10); vy += (ay * sp - vy) * Math.min(1, dt * 10);
  if (Math.abs(vx) > 2 || Math.abs(vy) > 2) { cam.x += vx * dt; cam.y += vy * dt; anim = null; follow = false; view(true); }
  const z = (keys.has("+") || keys.has("=") ? 1 : 0) - (keys.has("-") || keys.has("_") ? 1 : 0);
  if (z) zoomAt(cw / 2, ch / 2, cam.s * Math.exp(z * dt * 1.4));
  if (anim) {
    const t = Math.min(1, (now - anim.t0) / anim.dur), e = t < .5 ? 2 * t * t : 1 - 2 * (1 - t) * (1 - t);
    cam.s = anim.fs + (anim.ts - anim.fs) * e; cam.x = anim.fx + (anim.tx - anim.fx) * e - cw / 2 / cam.s; cam.y = anim.fy + (anim.ty - anim.fy) * e - ch / 2 / cam.s; view(false);
    if (t === 1) { const d = anim.done; anim = null; if (d) d(); }
  }
  if (taxiRun) {
    const R = taxiRun, t = Math.min((now - R.t0) / R.dur, 1), p = $("route").getPointAtLength(t * R.len), q = $("route").getPointAtLength(Math.min(t * R.len + 2, R.len));
    $("taxi").setAttribute("transform", `translate(${p.x} ${p.y}) rotate(${(Math.atan2(q.y - p.y, q.x - p.x) * 180) / Math.PI})`);
    const mt = $("mt"); mt.hidden = false; mt.setAttribute("cx", p.x); mt.setAttribute("cy", p.y);
    if (follow) { cam.x += (p.x - cw / 2 / cam.s - cam.x) * Math.min(1, dt * 4); cam.y += (p.y - ch / 2 / cam.s - cam.y) * Math.min(1, dt * 4); view(false); }
    if (t === 1) { taxiRun = null; follow = false; status.textContent = "Arrived at " + R.to + "."; setTimeout(() => { $("taxi").hidden = true; $("mt").hidden = true; $("route").setAttribute("d", ""); }, 1500); }
  }
  traffic.forEach((c, k) => {
    c.p += c.dir * c.sp * dt; const lim = c.horiz ? W : H; if (c.p > lim + 20) c.p = -20; if (c.p < -20) c.p = lim + 20;
    const lane = c.road * P + c.dir * 9, x = c.horiz ? c.p : lane, y = c.horiz ? lane : c.p;
    tEls[k].setAttribute("transform", `translate(${x} ${y}) rotate(${c.horiz ? (c.dir > 0 ? 0 : 180) : c.dir > 0 ? 90 : -90})`);
  });
  requestAnimationFrame(tick);
}
resize(); flyTo(1050, 750, 0.9); anim.dur = 1; requestAnimationFrame(tick);

// ---------- windows ----------
const listRows = (items) => items.map(([n, p]) => `<div class="row"><span>${n}</span><b>${money(p)}</b></div>`).join("");
function openPlace(id) {
  status.textContent = "Entered " + NAMES[id] + ".";
  if (id === "supermarket") openWindow("SUPERMARKET", `<h3>Fresh goods</h3>${listRows(SUPERMARKET_ITEMS)}`);
  else if (id === "carshop") openWindow("CAR SHOP", `<h3>Cars for sale</h3>${listRows(CARS)}`);
  else aptWindow(HOMES.find((h) => h.id === id));
}

// ---------- apartments + payment ----------
function aptWindow(h) {
  const price = finalPrice(h), own = OWNED[h.id];
  const priceHtml = (h.sale ? `<s>${money(h.price)}</s>` : "") + `<span class="big">${money(price)}</span>` + (h.sale ? `<span class="badge">-${h.sale}% SALE</span>` : "");
  openWindow(h.name.toUpperCase(), `<h3>${h.tag}</h3>
    <div class="row"><span>Rooms</span><b>${h.rooms}</b></div><div class="row"><span>Size</span><b>${h.size} m2</b></div><div class="row"><span>Floor</span><b>${h.floor}</b></div>
    <div class="pricebox">${priceHtml}</div>` + (own
    ? `<p class="ok">PAID - this apartment is yours.<br>Receipt ${own.receipt} (${own.method})</p>`
    : `<label class="field">Pay with<select id="payMethod"><option value="wallet">Wallet (${money(wallet)})</option><option value="card">Credit card</option></select></label>
       <div id="cardBox" hidden>
         <label class="field">Name on card<input id="cName" autocomplete="off"></label>
         <label class="field">Card number<input id="cNum" inputmode="numeric" placeholder="1234 5678 9012 3456" maxlength="19"></label>
         <div class="two"><label class="field">Expiry<input id="cExp" placeholder="MM/YY" maxlength="5"></label><label class="field">CVV<input id="cCvv" inputmode="numeric" maxlength="4"></label></div>
       </div>
       <div class="msg" id="payMsg"></div><button class="btn warn" id="payBtn">PAY ${money(price)}</button>`));
  if (own) return;
  $("payMethod").onchange = (e) => ($("cardBox").hidden = e.target.value !== "card");
  $("payBtn").onclick = () => pay(h);
}
function pay(h) {
  const price = finalPrice(h), method = $("payMethod").value, msg = $("payMsg"), bad = (t) => { msg.className = "msg"; msg.textContent = t; };
  if (method === "wallet") { if (wallet < price) return bad(`Not enough funds. You need ${money(price - wallet)} more. Try paying by card.`); }
  else {
    const num = $("cNum").value.replace(/\s/g, ""), exp = $("cExp").value.match(/^(0[1-9]|1[0-2])\/(\d{2})$/), now = new Date();
    if (!$("cName").value.trim()) return bad("Enter the name on the card.");
    if (!/^\d{16}$/.test(num)) return bad("Card number must be 16 digits.");
    if (!exp || +("20" + exp[2]) * 12 + +exp[1] < now.getFullYear() * 12 + now.getMonth() + 1) return bad("Expiry must be MM/YY and not in the past.");
    if (!/^\d{3,4}$/.test($("cCvv").value)) return bad("CVV must be 3 or 4 digits.");
  }
  if (method === "wallet") wallet -= price;
  const receipt = "SM-" + Math.random().toString(36).slice(2, 8).toUpperCase();
  OWNED[h.id] = { receipt, method, paid: price };
  window.onApartmentPaid({ apartment: h.id, name: h.name, paid: price, method, receipt });
  setWallet(); drawPlaces(); status.textContent = `Paid ${money(price)} for ${h.name}. Receipt ${receipt}.`; aptWindow(h);
}

// ---------- taxi (camera follows it) ----------
$("taxiBtn").addEventListener("click", () => {
  const options = Object.entries(NAMES).map(([k, v]) => `<option value="${k}">${v}</option>`).join("");
  openWindow("ORDER TAXI", `<h3>Where to?</h3>
    <label class="field">Pickup<select id="from">${options}</select></label>
    <label class="field">Destination<select id="to">${options}</select></label>
    <p>Fare: ${money(TAXI_FARE_PER_KM)} per km, paid from your wallet.</p><button class="btn warn" id="confirmTaxi">CALL TAXI</button>`);
  $("to").selectedIndex = 1;
  $("confirmTaxi").onclick = () => { const f = $("from").value, t = $("to").value; if (f === t) return alert("Pick two different places."); if (driveTaxi(f, t)) closeWindow(); };
});
function driveTaxi(from, to) {
  const [a, b] = [DOORS[from], DOORS[to]], mid = (a[0] + b[0]) / 2;
  const vxr = clamp(Math.round(mid / P) * P, P, 9 * P);
  const pts = a[1] === b[1] ? [a, b] : [a, [vxr, a[1]], [vxr, b[1]], b];
  const route = $("route"); route.setAttribute("d", "M" + pts.map((p) => p.join(" ")).join("L"));
  const len = route.getTotalLength(), km = Math.max(1, Math.round(len / 150)), fare = km * TAXI_FARE_PER_KM;
  if (fare > wallet) { route.setAttribute("d", ""); alert(`Not enough funds. Fare is ${money(fare)}.`); return false; }
  wallet -= fare; setWallet(); status.textContent = `Taxi on the way. ${km} km, fare ${money(fare)}.`;
  $("taxi").hidden = false; follow = true; anim = null; taxiRun = { t0: performance.now(), dur: len * 7, len, to: NAMES[to] };
  return true;
}

// ---------- search (flies the camera to the apartment) ----------
const input = $("homeSearch"), results = $("results");
const match = (q) => HOMES.filter((h) => (h.name + " " + h.tag + " " + h.keywords + " " + h.rooms + " room").toLowerCase().includes(q));
function showResults() {
  const q = input.value.trim().toLowerCase();
  if (!q) { results.hidden = true; return; }
  const hits = match(q);
  results.innerHTML = hits.length ? hits.map((h) => `<li data-id="${h.id}"><span>${h.name} - ${h.tag}</span><small>${money(finalPrice(h))}</small></li>`).join("")
    : `<li class="none">No homes found for "${q.replace(/</g, "&lt;")}".</li>`;
  results.hidden = false;
}
function openHome(h) {
  results.hidden = true; input.blur();
  document.querySelectorAll(".hl").forEach((e) => e.classList.remove("hl"));
  $(h.id).classList.add("hl"); status.textContent = "Flying to " + h.name + "...";
  const [cx, cy] = centerOf(h.id); flyTo(cx, cy, 1.1, () => aptWindow(h));
}
input.addEventListener("input", showResults);
input.addEventListener("keydown", (e) => { if (e.key === "Enter") { const h = match(input.value.trim().toLowerCase())[0]; if (h) openHome(h); } });
results.addEventListener("click", (e) => { const li = e.target.closest("li[data-id]"); if (li) openHome(HOMES.find((h) => h.id === li.dataset.id)); });
document.addEventListener("click", (e) => { if (!e.target.closest(".searchrow")) results.hidden = true; });
